import React from 'react'
import homeimg from '../../../src/images/home.jpg'
import home from './Home.module.css'
import Nav from '../Nav/Nav'
function Home() {
    return (
        <div className={home.main}>
            <Nav></Nav>
            <div className={home.img}><img src={homeimg} alt="" /></div>
        </div>
    )
}

export default Home

