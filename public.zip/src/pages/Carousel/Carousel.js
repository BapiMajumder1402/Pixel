import React, { useState } from 'react';
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import { data } from './Data';
import cro from './Carousel.module.css'
import{RxArrowLeft} from 'react-icons/rx'
import{RxArrowRight} from 'react-icons/rx'
import minus from '../../images/Minus.svg'

function CarouselCom() {
    const [activeIndex, setActiveIndex] = useState(0);

    const handleSlideLeft = () => {
        setActiveIndex((prevIndex) => (prevIndex === 0 ? data.length - 1 : prevIndex - 1));
    };

    const handleSlideRight = () => {
        setActiveIndex((prevIndex) => (prevIndex === data.length - 1 ? 0 : prevIndex + 1));
    };

    return (
        <div className={cro.main}>
            <div className={cro.up}>
                <div className={cro.left}>
                    <p>Integrated Approach</p>
                    <h4>Startup Development</h4>
                    <p>We bundle together all the elements that help
                        startups become more successful</p>
                </div>
                <div className={cro.right}>
                    <div>
                        <p>Explore More</p>
                        <div className={cro.lr}>
                            <p onClick={handleSlideLeft}><RxArrowLeft/></p>
                            <p onClick={handleSlideRight}><RxArrowRight/></p>
                        </div>
                    </div>


                </div>
            </div>
            <div className={cro.cro}>
                <Carousel
                    swipeable={false}
                    draggable={true}
                    showDots={false}
                    ssr={false}
                    infinite={true}
                    autoPlay={false}
                    autoPlaySpeed={1000}
                    keyBoardControl={true}
                    customTransition="all .5"
                    transitionDuration={500}
                    containerClass="carousel-container"
                    dotListClass="custom-dot-list-style"
                    itemClass="carousel-item-padding-40-px"
                    additionalTransfrom={activeIndex * -100}
                    responsive={{
                        desktop: {
                            breakpoint: { max: 3000, min: 1024 },
                            items: 3,
                            partialVisibilityGutter: 40
                        },
                        tablet: {
                            breakpoint: { max: 1024, min: 464 },
                            items: 2,
                            partialVisibilityGutter: 30
                        },
                        mobile: {
                            breakpoint: { max: 464, min: 0 },
                            items: 1,
                            partialVisibilityGutter: 20
                        }
                    }}
                >
                    {data.map((e) => (
                        <div key={e.id} className={cro.card}>
                            <div className={cro.img}>
                                <img src={e.img} alt="" />
                            </div>
                            <div className={cro.des}>
                                <h4 className={cro.title} >{e.title}</h4>
                                
                                <p>{e.details}</p>
                                <p className={cro.read}>Read More<RxArrowRight/></p>
                            </div>
                        </div>
                    ))}
                </Carousel>
            </div>
        </div>
    );
}

export default CarouselCom;
