import img1 from './Corporate-Meeting-in-Progress.jpg'
import img2 from './img-01.jpg'
import img3 from './img-02.jpg'
import img4 from './img-03.jpg'
import img5 from './mission.jpg'
import img6 from './vision.jpg'

export const data=[
    {
        id:1,
        img:img1,
        title:"Corporate Connections",
        details:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard"
    },
    {
        id:2,
        img:img2,
        title:"Mentorship",
        details:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard"
    },
    {
        id:3,
        img:img3,
        title:"Team Management",
        details:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard"
    },
    {
        id:4,
        img:img4,
        title:"Flexible Timing",
        details:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard"
    },
    {
        id:5,
        img:img5,
        title:"Way to Success",
        details:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard"
    },
    {
        id:6,
        img:img6,
        title:"Corporate Meetings",
        details:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard"
    },
]