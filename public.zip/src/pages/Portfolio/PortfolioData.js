import beardo from './logo/beardo.jpg'
import bharat from './logo/bharatpay.jpg'
import cout from './logo/cout.jpg'
import fynd from './logo/fynd.jpg'
import home from './logo/home.jpg'
import imo from './logo/imo.jpg'
import pee from './logo/pee.jpg'
import super1 from './logo/super.jpg'
import tree from './logo/tree.jpg'

export const data=[beardo,super1,tree, bharat,pee,imo,home,fynd,cout]