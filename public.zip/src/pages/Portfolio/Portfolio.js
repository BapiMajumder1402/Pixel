import React from 'react'
import { RxArrowDown } from 'react-icons/rx'
import port from './Portfolio.module.css'
import { data } from './PortfolioData'

function Portfolio() {
    return (
        <div className={port.main}>
            <div className={port.left}>
                <div>SHOWCASE</div>
                <h3>Portfolio</h3>
                <p>Since 2016, Start Your Own Business has backed over 110 startups across multiple sectors. We take immense pride in our founders achievements.</p>
                <div className={port.bottom}>
                    <div><RxArrowDown /></div>
                    <p>VIEW ALL</p>
                </div>
            </div>
            <div className={port.right}>
                <h4>Companies</h4>
                <div className={port.section}>
                {data.map((e, i) => (
                    <div key={i} className={port.logos}>
                        <div className={port.img}>
                            <img src={e} alt="" />
                        </div>
                    </div>
                ))}
                </div>
                
            </div>
        </div>
    )
}

export default Portfolio
