export  const data = [
    {
        id:1,
        bg:"orange",
        heading:"Realestate"
    }
]