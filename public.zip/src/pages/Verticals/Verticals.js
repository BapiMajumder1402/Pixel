import React from 'react'
import vartical from './Varticales.module.css'
function Verticals() {
    return (
        <div className={vartical.main}>
            
        </div>
    )
}

export default Verticals
