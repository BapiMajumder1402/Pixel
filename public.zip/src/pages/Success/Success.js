import React from 'react'
import ceo from './ceo.jpg'
import suc from './Success.module.css'
import beardo from './th-removebg-preview.png'
import{RxArrowLeft} from 'react-icons/rx'
import{RxArrowRight} from 'react-icons/rx'

function Success() {
    return (
        <div className={suc.main}>
            <div className={suc.top}>
                <div className={suc.left}>
                    <img src={ceo} alt="ceo" />
                </div>
                <div className={suc.right}>
                    <p>Success</p>
                    <div className={suc.heading}>
                        <h3>Startup Stories</h3>
                        <p>Creating the World’s Largest Community for Entrepreneurs and Investors</p>
                    </div>
                    <div><img src={beardo} alt="" /></div>
                    
                    <div className={suc.intro}>
                        <h4>Ashotosh Valani - Founder</h4>
                        <p>"Raising funds from Venture Catalysts certainly helped our business to expand our reach…"</p>
                        
                    </div>
                    <div className={suc.bot}>
                        <p className={suc.left_arrow}><RxArrowLeft/></p>
                        <p  className={suc.right_arrow}><RxArrowRight/></p>
                        <p className={suc.next}>NEXT SUCCESS STORY</p>
                    </div>

                </div>
            </div>
            <div className={suc.bottom}>
                <div className={suc.headline}>

                    <p>Let’s get started! As a budding entrepreneur, you can</p>
                    <p>apply for raising funds & as for investors, if you’re </p> <p>looking to join the network, click below.</p> 
                </div>
                <div className={suc.btns}>
                    <div>Startups looking to raise funds</div>
                    <div>Investors looking to join the network</div>
                </div>
            </div>
        </div>
    )
}

export default Success
