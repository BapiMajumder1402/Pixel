import React from 'react';
import intro from './Introduction.module.css';

function Introduction() {
    return (
        <div className={intro.main}>
            <div className={intro.black}>
                <p>Introduction</p>
                <h4>Our Stories</h4>
                <p>Since 2016, Start Your Own Business has backed over 110 startups across multiple sectors. We take immense pride in our founders achievements.</p>
            </div>
            <div className={intro.white}>
                <div className={intro.video}>
                    <iframe
                        width="1300"
                        height="450"
                        src="https://www.youtube.com/embed/7tz4Ya6gzG4"
                        title="YouTube video player"
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowFullScreen
                        
                    ></iframe>
                </div>
            </div>
        </div>
    );
}

export default Introduction;



