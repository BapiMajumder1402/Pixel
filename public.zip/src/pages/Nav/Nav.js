import React from 'react'
import nav from './Nav.module.css'
import { RxHamburgerMenu } from "react-icons/rx"
import { HiOutlineArrowDown } from "react-icons/hi"
import play from '../../images/play-btn.svg'
import top from '../../images/top.svg'

function Nav() {
    return (
        <div>
            <div className={nav.main}>
                <div className={nav.img}><img src={top} alt="" /></div>
                <div className={nav.right}>
                    <div className={nav.links}>
                        <p>Home</p>
                        <p>About</p>
                        <p>People</p>
                        <p>Portfolio</p>
                        <p>News&Media</p>
                        <p>Blog</p>
                        <p>Contact</p>
                        <button>
                            LOGIN
                        </button>
                        <p><RxHamburgerMenu /></p>
                        
                    </div>
                    <div id={nav.red} className={nav.red}>
                            LET'S TALK
                        </div>
                </div>

            </div>
            <div>
                <div>
                    <div className={nav.box}>
                        <p>Creating the</p>
                        <p id={nav.color}>INDIA’s Largest</p>
                        <p>Early Stage Startup</p>
                        <p>Ecosystem</p>
                    </div>
                    <div className={nav.scroll}>
                        <div className={nav.svg}><HiOutlineArrowDown/></div>
                        <div>SCROLL DOWN</div>
                    </div>
                </div>
                <div>
                <div className={nav.rbox}>
                    We’ll help you connect with your customers
                    through the power of our experience – wherever, however.
                    
                </div>
                <div className={nav.play}>
                    <img src={play} alt="" />
                    <p>WATCH Now</p>
                </div>
                </div>
                
            </div>
        </div>

    )
}

export default Nav
