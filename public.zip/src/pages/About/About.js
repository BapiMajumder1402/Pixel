import React from 'react'
import about from './About.module.css'
import {data} from './AboutData'
import minus from '../../images/Minus.svg'
import hex from '../../images/hexa.svg'
export default function About() {
  return (
    <div className={about.main}>
        <div className={about.box}>
            <div div className={about.about}>
                <div div className={about.top}> <span>ABOUT COMPANY</span> <img src={minus} alt="" /> </div>
                <div div className={about.bottom}>At Start Your Own Business we partner with our customers to address their most pressing challenges while enabling their performance through technology and innovation on a path marked by excellence in everything we do. With more than 5,500 employees across 20 countries, Start Your Own Business well services portfolio includes, Coiled Tubing & Stimulation, Cementing, Wireline, Frac, Directional Drilling, Downhole Tools, Completions, Well Testing, Slickline, Inspection, H2S Safety, and Logging & Perforating.</div>
            </div>
            <div div className={about.achivments}>
            {
              data.map((e)=>{
                return(
                  <div key={e.id} div className={about.section}>
                    <div div className={about.svg}>{e.svg}</div>
                    <div div className={about.data}>
                      <p div className={about.red}>{e.count}</p>
                      <p div className={about.white}>{e.details}</p>
                    </div>
                  </div>
                )
              })
            }
            </div>
        </div>
        <div div className={about.hex}>
          <img src={hex} alt="" />
        </div>
      
    </div>
  )
}

