import {CgFileDocument} from 'react-icons/cg'
import {RxRocket} from 'react-icons/rx'
import {TbTargetArrow} from 'react-icons/tb'
import {TbChartHistogram} from 'react-icons/tb'

export const data =[
    {
        id:1,
        svg:<CgFileDocument/>,
        count:"$ 720 Mn +",
        details:"Syndicated acrossthe portfolio",
    },
    {
        id:2,
        svg:<RxRocket/>,
        count:"300+",
        details:"StartUps",
    },
    {
        id:3,
        svg:<TbTargetArrow/>,
        count:"98 +",
        details:"Exit & Up rounds",
    },
    {
        id:4,
        svg:<TbChartHistogram/>,
        count:"22000",
        details:"Startups Evaluated",
    },
]