
import './App.css';
import Home from './pages/Home/Home'
import About from './pages/About/About';
import Portfolio from './pages/Portfolio/Portfolio';
import Introduction from './pages/Introduction/Introduction';
import CarouselCom from './pages/Carousel/Carousel';
import Success from './pages/Success/Success';
function App() {
  return (
    <div >
      <Home/>
      <About/>
      <Portfolio/>
      <Introduction/>
      <CarouselCom/>
      <Success/>
    </div>
  );
}

export default App;
